ADMIN = ['7313978335481778970']  # thay id admin đi thg cu
