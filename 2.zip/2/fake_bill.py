import requests

def create_fake_bill():
    # Thiết lập các tham số cho API fake bill
    params = {
        'name_gui': 'dung',
        'stk_gui': '1234567897749',
        'bank': 'ACB',
        'code1': 'Vietinbank',
        'code': 'ICB',
        'stk': '1234567897769',
        'name_nhan': 'buoitovc',
        'amount': '123456789456123',
        'noidung': 'done',
        'magiaodich': 'FT2227683771',
        'time1': '18:51:35,20/03/2024',
        'hinhthucck': 'Ngoài',
        'thoigianhientai': '18:51',
        'apikey': 'DUNGKON_2002'
    }

    # Gọi API để tạo fake bill
    response = requests.get("https://apiquockhanh.click/fakebill", params=params)

    # Kiểm tra mã trạng thái phản hồi
    if response.status_code == 200:
        # Nếu thành công, trả về thông tin hóa đơn
        return response.json()  # Giả sử API trả về JSON
    else:
        # Nếu có lỗi, in ra thông báo lỗi
        print(f"Error: {response.status_code} - {response.text}")
        return None

# Ví dụ cách gọi hàm
bill_info = create_fake_bill()
if bill_info:
    print("Fake bill created successfully:", bill_info)