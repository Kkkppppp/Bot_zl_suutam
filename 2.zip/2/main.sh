import time
import os
import sys
import threading
from config import API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES
from zlapi.models import *
from mitaizl import CommandHandler
from zlapi import ZaloAPI
from colorama import Fore, Style, init
from pyfiglet import figlet_format
from modules.welcome import welcome

# Khởi tạo colorama
init(autoreset=True)

class MrQ(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        self.admin = "6893917462711041630"
        self.version = 1.0
        self.me_name = "Bot by Mr V"
        self.date_update = "29/9/2024"
        self.command_handler = CommandHandler(self)

    def onEvent(self, event_data, event_type):
        welcome(self, event_data, event_type)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        print(f"{Fore.GREEN}{Style.BRIGHT}------------------------------\n"
              f"- Message: {Style.BRIGHT}{message} {Style.NORMAL}\n"
              f"- ID NGƯỜI DÙNG: {Fore.MAGENTA}{Style.BRIGHT}{author_id} {Style.NORMAL}\n"
              f"- ID NHÓM: {Fore.YELLOW}{Style.BRIGHT}{thread_id}{Style.NORMAL}\n"
              f"{Fore.GREEN}{Style.BRIGHT}------------------------------\n")
        
        if isinstance(message, str):
            self.command_handler.handle_command(message, author_id, message_object, thread_id, thread_type)

    def restart_project(self):
        while True:
            time.sleep(1800)  # 30 phút
            gui = "Bot sẽ khởi động lại ngay bây giờ...\nBot sẽ tiến hành tự động khởi động lại"
            print(gui)

            self.send(
                Message(gui),
                thread_id=self.admin,  # Sử dụng ID admin để gửi thông báo
                thread_type=ThreadType.USER,
                ttl=60000
            )
            os.execv(sys.executable, [sys.executable] + sys.argv)

    def print_colored_text(self, text, font="slant"):
        colored_text = f"{Fore.CYAN}{Style.BRIGHT}{figlet_format(text, font=font)}{Style.RESET_ALL}"
        print(colored_text)

    def send_welcome_message(self):
        welcome_message = "Chào mừng bạn đến với Bot của Trường Thịnh! Hãy tận hưởng nhé!"
        self.send(
            Message(welcome_message),
            thread_id=self.admin,  # Thay thế bằng ID nhóm hoặc ID người dùng
            thread_type=ThreadType.USER,
            ttl=60000
        )

if __name__ == "__main__":
    while True:
        try:
            mrq_bot = MrQ(API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES)
            threading.Thread(target=mrq_bot.restart_project, daemon=True).start()

            # In ra chữ "Trường Thịnh" với phông chữ slant
            mrq_bot.print_colored_text("Truong Thinh", font="slant")

            # Gửi tin nhắn chào mừng khi bot khởi động
            mrq_bot.send_welcome_message()

            mrq_bot.listen(thread=True)
        except Exception as e:
            print(f"{Fore.RED}Error initializing MrQ: {e}")
            time.sleep(0.5)