from zlapi.models import *
import json
import random
import requests
import time
import os
from PIL import Image
from io import BytesIO
# Các thông số trò chơi
timeLimit = 300  # Thời gian giới hạn trả lời (300 giây = 5 phút)
admin_ids = "7313978335481778970"
# Lưu trữ session trò chơi
game_sessions = {}
def handle_dhbc_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split()
# File lưu trữ thông tin điểm danh theo ngày
attendance_file = 'modules/dhbc/attendance.json'

# Hàm đọc dữ liệu từ file JSON
def read_json(file):
    try:
        if os.path.exists(file):
            with open(file, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            print(f"[WARNING] File không tồn tại: {file}")
            return {}
    except json.JSONDecodeError as e:
        print(f"[ERROR] Lỗi khi đọc file JSON: {file}, Chi tiết: {e}")
        return {}

# Hàm ghi dữ liệu vào file JSON
def write_json(file, data):
    try:
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"[ERROR] Lỗi khi ghi dữ liệu vào file {file}: {e}")

# Lưu điểm người chơi vào bảng xếp hạng
def save_score(user_id, score):
    leaderboard = read_json('modules/dhbc/scoreboard.json')
    leaderboard[user_id] = leaderboard.get(user_id, 0) + score
    write_json('modules/dhbc/scoreboard.json', leaderboard)

# Hàm xử lý điểm danh
def handle_attendance(user_id, client, thread_id, thread_type):
    today = datetime.today().strftime('%Y-%m-%d')  # Lấy ngày hiện tại (dạng YYYY-MM-DD)
    attendance_data = read_json(attendance_file)
    
    # Kiểm tra nếu người chơi đã điểm danh hôm nay chưa
    if str(user_id) in attendance_data and attendance_data[str(user_id)] == today:
        client.sendMessage(
            Message(text="⚠️ Bạn đã điểm danh hôm nay rồi. Bạn chỉ có thể điểm danh một lần trong ngày."),
            thread_id=thread_id,
            thread_type=thread_type,
        )
        return

    # Cập nhật thông tin điểm danh vào file
    attendance_data[str(user_id)] = today
    write_json(attendance_file, attendance_data)
    
    # Cộng 50 điểm cho người chơi khi điểm danh thành công
    save_score(user_id, 100)
    
    # Thông báo cho người chơi
    client.sendMessage(
        Message(text="🎉 Chúc mừng bạn đã điểm danh thành công và nhận 100 điểm!"),
        thread_id=thread_id,
        thread_type=thread_type,
    )

# Hàm lấy thông tin xếp hạng và điểm của người chơi
def get_current_top_and_score(user_id):
    leaderboard = read_json('modules/dhbc/scoreboard.json')
    user_score = leaderboard.get(str(user_id), 0)
    sorted_leaderboard = sorted(leaderboard.items(), key=lambda x: x[1], reverse=True)
    position = next((i + 1 for i, (uid, _) in enumerate(sorted_leaderboard) if uid == str(user_id)), None)
    return position, user_score

# Hàm tải và kiểm tra kích thước ảnh
def get_image_dimensions(url, headers):
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Kiểm tra HTTP status
        image = Image.open(BytesIO(response.content))
        image.verify()  # Xác minh tính hợp lệ của ảnh
        return image.size
    except requests.exceptions.RequestException as req_error:
        print(f"[ERROR] Lỗi khi tải ảnh từ URL {url}: {req_error}")
    except Exception as e:
        print(f"[ERROR] Lỗi không xác định khi xử lý ảnh từ URL {url}: {e}")
    return None, None

# Gửi câu hỏi tiếp theo
# Ghi lại danh sách các câu hỏi đã được hỏi
asked_questions = set()

# Gửi câu hỏi tiếp theo
def send_next_question(thread_id, thread_type, client):
    try:
        # Kiểm tra nếu đã có câu hỏi đang chờ
        if thread_id in game_sessions and game_sessions[thread_id]:
            client.sendMessage(
                Message(text="⚠️ Bạn vẫn còn một câu hỏi chưa trả lời. Hãy trả lời câu hỏi đó trước khi bắt đầu câu hỏi mới."),
                thread_id=thread_id,
                thread_type=thread_type,
            )
            return

        # Tiến hành gửi câu hỏi mới
        print(f"[DEBUG] Đang xử lý câu hỏi cho thread_id: {thread_id}")
        data = read_json('modules/dhbc/data.json')

        # Kiểm tra dữ liệu câu hỏi
        if not data or 'doanhinh' not in data or not data['doanhinh']:
            raise ValueError("Dữ liệu câu hỏi không hợp lệ hoặc trống.")

        # Lọc các câu hỏi chưa được hỏi
        available_questions = [
            question for question in data['doanhinh']
            if question['tukhoa'] not in asked_questions
        ]

        if not available_questions:
            client.sendMessage(
                Message(text="❌ Không còn câu hỏi mới nào. Vui lòng nạp thêm câu hỏi!"),
                thread_id=thread_id,
                thread_type=thread_type,
            )
            return

        # Chọn một câu hỏi ngẫu nhiên từ danh sách chưa được hỏi
        question = random.choice(available_questions)
        asked_questions.add(question['tukhoa'])  # Đánh dấu câu hỏi đã được hỏi
        print(f"[DEBUG] Câu hỏi được chọn: {question}")

        # Tải ảnh
        headers = {'User-Agent': 'Mozilla/5.0'}
        image_path = 'modules/dhbc/cache/next_question.png'
        image_response = requests.get(question['link'], headers=headers)
        image_response.raise_for_status()
        with open(image_path, 'wb') as f:
            f.write(image_response.content)
        print(f"[DEBUG] Ảnh đã được lưu tại {image_path}")

        # Lấy kích thước ảnh
        width, height = get_image_dimensions(question['link'], headers)
        if not width or not height:
            raise ValueError("Kích thước ảnh không xác định.")

        # Tạo gợi ý và gửi câu hỏi
        hint = f"Từ này có {question['sokitu']} ký tự.\n"
        if 'suggestions' in question:
            hint += f"Gợi ý: {' '.join(question['suggestions'])}"

        message_to_send = Message(
            text=f"Vui lòng trả lời câu hỏi dưới đây\n{hint}\n⏰ Bạn có {timeLimit}s = 5 phút để trả lời"
        )
        sent_message = client.sendLocalImage(
            image_path,
            message=message_to_send,
            thread_id=thread_id,
            thread_type=thread_type,
            width=width,
            height=height,
        )
        print(f"[DEBUG] Tin nhắn đã được gửi: {sent_message}")

        # Lưu trạng thái câu hỏi
        game_sessions[thread_id] = {
            sent_message.msgId: {
                "tukhoa": question['tukhoa'],
                "timestamp": time.time(),
            }
        }
    except ValueError as e:
        print(f"[ERROR] Lỗi dữ liệu câu hỏi: {e}")
        client.sendMessage(
            Message(text=f"Đã xảy ra lỗi: {e}"),
            thread_id=thread_id,
            thread_type=thread_type,
        )
    except Exception as e:
        print(f"[ERROR] Lỗi không mong muốn: {e}")
        client.sendMessage(
            Message(text=f"Đã xảy ra lỗi khi gửi câu hỏi: {e}"),
            thread_id=thread_id,
            thread_type=thread_type,
        )

def get_user_name_by_id(bot, author_id):
    try:
        user_info = bot.fetchUserInfo(author_id).changed_profiles[author_id]
        return user_info.zaloName or user_info.displayName
    except Exception:
        return "Unknown User"

# Hàm xử lý điểm khi trả lời đúng hoặc sai
def handle_answer(message, thread_id, thread_type, user_id, client, is_correct, is_quitting=False):
    try:
        position, user_score = get_current_top_and_score(user_id)
        user = get_user_name_by_id(client, user_id)

        # Kiểm tra nếu 'message' là một từ điển và có khóa 'tukhoa'
        if isinstance(message, dict) and 'tukhoa' in message:
            correct_answer = message['tukhoa']
        else:
            # Nếu 'message' không phải là từ điển hoặc không có 'tukhoa', sử dụng dữ liệu từ game_sessions
            if thread_id in game_sessions:
                session = game_sessions[thread_id]
                for msg_id, data in session.items():
                    correct_answer = data["tukhoa"]
                    break
            else:
                correct_answer = None  # Nếu không tìm thấy câu trả lời đúng, để trống

        # Cộng hoặc trừ điểm
        if is_quitting:
            save_score(user_id, -5)  # Trừ 5 điểm khi đầu hàng
            response_message = f"❌ {user} đã đầu hàng!\n{user} bị trừ [20] điểm khi đầu hàng\nTổng điểm: {user_score - 20}\nTop: {position} trong bảng xếp hạng.\nBạn sẽ bị trừ 5 điểm khi không trả lời."
        elif is_correct:
            save_score(user_id, 10)  # Cộng 10 điểm khi trả lời đúng
            response_message = f"🎉 Chúc mừng {user} đã trả lời đúng!\n{user} được cộng [10] điểm khi trả lời đúng\nTổng điểm: {user_score + 10}\nTop: {position} trong bảng xếp hạng."
        else:
            save_score(user_id, -5)  # Trừ 5 điểm khi trả lời sai
            response_message = f"❌ Rất tiếc {user} đã trả lời sai.\n{user} bị trừ [5] điểm khi trả lời sai\nTổng điểm: {user_score - 5}\nTop: {position} trong bảng xếp hạng."

        # Thêm bảng xếp hạng vào thông báo
        leaderboard_message = get_leaderboard()  # Lấy bảng xếp hạng
        response_message += f"\n=============================\n{leaderboard_message}"

        # Gửi thông báo phản hồi
        mention = Mention(uid=user_id, length=len(user), offset=response_message.index(user))
        client.send(
            Message(text=response_message, mention=mention),
            thread_id=thread_id,
            thread_type=thread_type,
        )

        # Nếu trả lời đúng, gửi câu hỏi tiếp theo
        if is_correct and not is_quitting:
            if thread_id in game_sessions:
                del game_sessions[thread_id]
            send_next_question(thread_id, thread_type, client)

    except Exception as e:
        print(f"[ERROR] Lỗi khi xử lý trả lời: {e}")
        client.sendMessage(
            Message(text=f"Đã xảy ra lỗi khi xử lý câu trả lời: {e}"),
            thread_id=thread_id,
            thread_type=thread_type,
        )


# Xử lý lệnh đầu hàng
def handle_quit_command(message, thread_id, thread_type, user_id, client):
    if thread_id in game_sessions:
        session = game_sessions[thread_id]
        for msg_id, data in session.items():
            # Thông báo người chơi đã đầu hàng
            handle_answer(message, thread_id, thread_type, user_id, client, is_correct=False, is_quitting=True)
            # Xóa session nếu người chơi đầu hàng
            del game_sessions[thread_id][msg_id]
            return

    # Nếu không có câu hỏi nào đang chơi
    client.sendMessage(
        Message(text="⚠️ Bạn chưa tham gia câu hỏi nào để đầu hàng."),
        thread_id=thread_id,
        thread_type=thread_type,
    )

# Hàm lấy bảng xếp hạng
def get_leaderboard(client):
    leaderboard = read_json('modules/dhbc/scoreboard.json')
    sorted_leaderboard = sorted(leaderboard.items(), key=lambda x: x[1], reverse=True)
    leaderboard_message = "🎉Bảng xếp hạng🎯:\n"

    # Lấy 5 người đứng đầu
    for i, (user_id, score) in enumerate(sorted_leaderboard[:10]):
        user_name = get_user_name_by_id(client, user_id)  # Lấy tên người chơi
        leaderboard_message += f"{i + 1}. {user_name} [{score}] điểm\n"

    return leaderboard_message

# Hàm để gửi đáp án cho admin
def send_answer_for_admin(thread_id, thread_type, client):
    try:
        if thread_id not in game_sessions or not game_sessions[thread_id]:
            client.sendMessage(
                Message(text="⚠️ Không có câu hỏi nào đang chờ giải đáp."),
                thread_id=thread_id,
                thread_type=thread_type,
            )
            return

        session = game_sessions[thread_id]
        for msg_id, data in session.items():
            correct_answer = data["tukhoa"]
            client.sendMessage(
                Message(text=f"Đáp án là: [{correct_answer}]\n🤪Chơi game vui vẻ\nKhông cay bạn nhé🤣"),
                thread_id=thread_id,
                thread_type=thread_type,
            )

    except Exception as e:
        print(f"[ERROR] Lỗi khi gửi đáp án cho admin: {e}")
        client.sendMessage(
            Message(text=f"Đã xảy ra lỗi khi gửi đáp án: {e}"),
            thread_id=thread_id,
            thread_type=thread_type,
        )

# Đường dẫn ảnh vịt cơ bản, ảnh chờ và GIF đua vịt
duck_base_image_path = "modules/dhbc/assets/duck.png"  # Ảnh vịt mẫu
waiting_image_path = "modules/dhbc/assets/waiting.png"  # Ảnh thông báo chờ
duck_race_gif_path = "modules/dhbc/assets/duck_race.gif"  # GIF đua vịt

# Số lượng người chơi (số vịt)
num_ducks = 100
ducks = [f"🦆 {i+1}" for i in range(num_ducks)]  # Gắn số thứ tự cho mỗi vịt

# Hàm tạo ảnh vịt với số đã chọn
def create_duck_image(duck_number, output_path):
    try:
        base_image = Image.open(duck_base_image_path)
        draw = ImageDraw.Draw(base_image)
        font = ImageFont.truetype("arial.ttf", 50)

        # Thêm số lên lưng vịt
        text_position = (base_image.width // 2 - 20, base_image.height // 2 - 20)
        draw.text(text_position, duck_number, fill="red", font=font)

        # Lưu ảnh kết quả
        base_image.save(output_path)
    except Exception as e:
        print(f"[ERROR] Lỗi khi tạo ảnh vịt chiến thắng: {e}")

# Hàm bắt đầu cuộc đua vịt
def start_duck_race(thread_id, thread_type, client, player_choice):
    try:
        if player_choice not in ducks:
            client.sendMessage(
                Message(text="❌ Vịt bạn chọn không hợp lệ! Vui lòng chọn lại số vịt."),
                thread_id=thread_id,
                thread_type=thread_type,
            )
            return

        client.sendMessage(
            Message(text="🦆 Cuộc đua vịt sắp bắt đầu! Vui lòng chờ..."),
            thread_id=thread_id,
            thread_type=thread_type,
        )

        client.sendLocalImage(
            waiting_image_path,
            thread_id=thread_id,
            thread_type=thread_type,
        )

        time.sleep(5)

        # Đếm ngược từ 3
        for i in range(3, 0, -1):
            client.sendMessage(
                Message(text=f"{i}..."),
                thread_id=thread_id,
                thread_type=thread_type,
            )
            time.sleep(1)

        client.sendMessage(
            Message(text="🏁 Cuộc đua vịt bắt đầu!"),
            thread_id=thread_id,
            thread_type=thread_type,
        )

        # Gửi GIF đua vịt
        client.sendLocalGif(
            duck_race_gif_path,
            thumbnailUrl="modules/dhbc/assets/duck_race_thumbnail.jpg",
            thread_id=thread_id,
            thread_type=thread_type,
        )

        time.sleep(10)  # Thời gian chờ giả lập đua

        # Xác định kết quả ngẫu nhiên
        winner_duck = random.choice(ducks)
        race_image_path = "modules/dhbc/assets/duck_winner.png"
        create_duck_image(winner_duck.split()[1], race_image_path)

        # Gửi thông báo kết quả
        if player_choice == winner_duck:
            # Cộng 10 điểm cho người chơi thắng
            save_score(thread_id, 10)  # Cộng điểm vào bảng xếp hạng
            client.sendMessage(
                Message(text=f"🎉 Chúc mừng bạn! Vịt của bạn ({player_choice}) đã chiến thắng và bạn nhận được 10 điểm!"),
                thread_id=thread_id,
                thread_type=thread_type,
            )
        else:
            client.sendMessage(
                Message(text=f"😢 Rất tiếc, vịt của bạn ({player_choice}) đã thua. Vịt thắng cuộc là {winner_duck}."),
                thread_id=thread_id,
                thread_type=thread_type,
            )

        # Gửi ảnh vịt chiến thắng
        client.sendLocalImage(
            race_image_path,
            message=Message(text=f"Vịt thắng cuộc: {winner_duck}"),
            thread_id=thread_id,
            thread_type=thread_type,
        )

    except Exception as e:
        print(f"[ERROR] Lỗi khi bắt đầu đua vịt: {e}")
        client.sendMessage(
            Message(text=f"Đã xảy ra lỗi khi bắt đầu đua vịt: {e}"),
            thread_id=thread_id,
            thread_type=thread_type,
        )

def handle_dhbc_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        content = message.strip().split()
        user_id = author_id
        # Đọc dữ liệu người chơi từ file
        users = read_json('modules/dhbc/data_user.json')
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
        }

        headers2 = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36 Edg/129.0.0.0'
        }

        # Initialize or retrieve game session for this thread
        if thread_id not in game_sessions:
            game_sessions[thread_id] = {}

        if not message_object.quote:
            # Khi không phải là reply, tạo câu hỏi mới
            if len(content) < 2:
                url_dhbc = 'https://i.imgur.com/WxpP7YF.jpeg'
                image_path = 'modules/dhbc/cache/dhbc.png'
                image_response = requests.get(url_dhbc, headers=headers)
                with open(image_path, 'wb') as f:
                    f.write(image_response.content)
                # Get the image dimensions
                width, height = get_image_dimensions(url_dhbc, headers)
                client.sendLocalImage(
                    image_path,
                    message=Message(text="== [ ĐUỔI HÌNH BẮT CHỮ ] ==\n──────────────────\nVui lòng chọn chế độ chơi:\n1. Một ảnh\n2. Hai ảnh"),
                    thread_id=thread_id,
                    thread_type=thread_type,
                    width=width,
                    height=height,ttl=15000
                )
                return
            
            if content[1] == '1':
                if decrease_user_money(user_id, coinstart):
                    user_data = get_user_data(user_id)
                    data_file_path = 'modules/dhbc/data.json'
                    data = load_data_from_file(data_file_path)
                    current_question = random.randint(0, len(data['doanhinh']) - 1)
                    question = data['doanhinh'][current_question]

                    # Tải và gửi hình ảnh
                    image_path = 'modules/dhbc/cache/anh1.png'
                    image_response = requests.get(question['link'], headers=headers)
                    with open(image_path, 'wb') as f:
                        f.write(image_response.content)

                    # Get the image dimensions
                    width, height = get_image_dimensions(question['link'], headers)

                    # Send the image with question details
                    message_to_send = Message(
                        text=f"Đã trừ {coinstart}₫ từ tài khoản của bạn để bắt đầu trò chơi.\nSố dư hiện tại: {user_data['money']}₫\n\n\nVui lòng reply tin nhắn này để trả lời\nGợi ý: {question['sokitu']}\n\nReply: '-dhbc gợi ý' - để xem gợi ý (-{coinsdown}₫)\n⏰ Bạn có {timeLimit}s để trả lời"
                    )
                    sent_message = client.sendLocalImage(
                        image_path,
                        message=message_to_send,
                        thread_id=thread_id,
                        thread_type=thread_type,
                        width=width,
                        height=height,ttl=50000
                    )

                    print(f'SEND MESSSSSS: {sent_message}')

                    # Store game state by message ID
                    game_sessions[thread_id][sent_message.msgId] = {
                        "tukhoa": question['tukhoa'],
                        "suggestions": question['suggestions'],
                        "timestamp": time.time()
                    }
                else:
                    client.replyMessage(
                        Message(text="@MEMBER, Bạn không đủ tiền để bắt đầu trò chơi.", mention=Mention(author_id, length=len('@MEMBER'), offset=0)),
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type,ttl=40000
                     
                    )
                    return

            elif content[1] == '2':
                if decrease_user_money(user_id, coinstart):
                    user_data = get_user_data(user_id)
                    data_file_path = 'modules/dhbc/data.json'
                    data = load_data_from_file(data_file_path)
                    current_question = random.randint(0, len(data['doanhinh_2']) - 1)
                    question = data['doanhinh_2'][current_question]

                    # Tải và gửi hình ảnh thứ nhất
                    image_path_1 = 'modules/dhbc/cache/anh2.png'
                    image_response_1 = requests.get(question['link1'], headers=headers)
                    with open(image_path_1, 'wb') as f1:
                        f1.write(image_response_1.content)

                    # Tải và gửi hình ảnh thứ hai
                    image_path_2 = 'modules/dhbc/cache/anh3.png'
                    image_response_2 = requests.get(question['link2'], headers=headers)
                    with open(image_path_2, 'wb') as f2:
                        f2.write(image_response_2.content)

                    # Danh sách ảnh cần gửi
                    image_path = [image_path_1, image_path_2]

                    # Send the image with question details
                    message_to_send = Message(
                        text=f"Đã trừ {coinstart}₫ từ tài khoản của bạn để bắt đầu trò chơi.\nSố dư hiện tại: {user_data['money']}₫\n\n\nVui lòng reply tin nhắn này để trả lời\nGợi ý: {question['sokitu']}\n\nReply: '!dhbc gợi ý' - để xem gợi ý (-{coinsdown}₫)\n⏰ Bạn có {timeLimit}s để trả lời"
                    )
                    client.sendMultiLocalImage(
                        image_path,
                        # message=message_to_send,
                        thread_id=thread_id,
                        thread_type=thread_type,ttl=50000
                        # width=width,
                        # height=height
                    )

                    sent_message = client.sendMessage(message_to_send, thread_id, thread_type)

                    print(f'SEND MESSSSSS: {sent_message}')

                    # Store game state by message ID
                    game_sessions[thread_id][sent_message.msgId] = {
                        "tukhoa": question['tukhoa'],
                        "suggestions": question['suggestions'],
                        "timestamp": time.time()
                    }
                else:
                    client.replyMessage(
                        Message(text="@MEMBER, Bạn không đủ tiền để bắt đầu trò chơi.", mention=Mention(author_id, length=len('@MEMBER'), offset=0)),
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type,ttl=15000
                    )
                    return
            elif content[1] == 'bxh':
                # Đọc dữ liệu người chơi từ file
                users = read_json('modules/dhbc/data_user.json')
                
                # Sắp xếp người chơi theo số tiền giảm dần
                sorted_users = sorted(users.items(), key=lambda x: x[1]['money'], reverse=True)
                
                # Lấy top 10 người chơi giàu nhất
                leaderboard = sorted_users[:10]

                # Tạo nội dung hiển thị bảng xếp hạng
                leaderboard_message = "== [ BẢNG XẾP HẠNG ] ==\n"
                for i, (user_id, user_data) in enumerate(leaderboard, start=1):
                    user_info = client.fetchUserInfo(user_id)
                    if user_info and 'changed_profiles' in user_info and user_id in user_info['changed_profiles']:
                        display_name = user_info['changed_profiles'][user_id].get('displayName', user_id)
                        leaderboard_message += f"{i}. {display_name}: {user_data['money']}₫\n"
                    else:
                        leaderboard_message += f"{i}. {user_id}: {user_data['money']}₫\n"

                # Gửi bảng xếp hạng
                client.sendMessage(
                    Message(text=leaderboard_message),
                    thread_id=thread_id,
                    thread_type=thread_type
                )
                return
            # Lệnh set tiền: -dhbc set (số tiền) [@user] 
            elif content[1] == 'set':
                # Kiểm tra xem người dùng hiện tại có phải là admin hay không (tùy vào logic của bạn)
                if author_id != ADMIN_ID:
                    client.replyMessage(
                        Message(text="@MEMBER, Bạn không có quyền thực hiện lệnh này!", mention=Mention(author_id, length=len('@MEMBER'), offset=0)),
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type,ttl=15000
                    )
                    return

                # Lấy số tiền muốn set
                try:
                    amount = int(content[2])
                except (ValueError, IndexError):
                    client.replyMessage(
                        Message(text="@MEMBER, Số tiền không hợp lệ! Vui lòng nhập số tiền hợp lệ.", mention=Mention(author_id, length=len('@MEMBER'), offset=0)),
                        message_object,
                        thread_id=thread_id,
                        thread_type=thread_type,ttl=15000
                    )
                    return

                # Kiểm tra xem admin muốn set tiền cho người khác hay cho bản thân
                if message_object.mentions:
                    # Set tiền cho người khác (có tag @user)
                    mentioned_user_id = message_object.mentions[0]['uid']
                    user_info = client.fetchUserInfo(mentioned_user_id)
                    if user_info and 'changed_profiles' in user_info and mentioned_user_id in user_info['changed_profiles']:
                        display_name = user_info['changed_profiles'][mentioned_user_id].get('displayName', mentioned_user_id)
                    else:
                        display_name = mentioned_user_id

                    if mentioned_user_id in users:
                        users[mentioned_user_id]['money'] = amount
                        client.sendMessage(
                            Message(text=f"Đã set số tiền của {display_name} thành {amount}₫"),
                            thread_id=thread_id,
                            thread_type=thread_type,
                            ttl=30000
                        )
                    else:
                        client.sendMessage(
                            Message(text="Người dùng không tồn tại trong hệ thống!"),
                            thread_id=thread_id,
                            thread_type=thread_type,
                            ttl=30000
                        )

                else:
                    # Set tiền cho chính mình
                    if user_id in users:
                        users[user_id]['money'] = amount
                        client.sendMessage(
                            Message(text=f"Đã set số tiền của bạn thành {amount}₫"),
                            thread_id=thread_id,
                            thread_type=thread_type
                        )
                    else:
                        client.sendMessage(
                            Message(text="Bạn không có tài khoản trong hệ thống!"),
                            thread_id=thread_id,
                            thread_type=thread_type
                            
                        )

                # Lưu lại thay đổi vào file
                write_json('modules/dhbc/data_user.json', users)
                return
            elif content[1] == 'sodu':
                if message_object.mentions:
                    mentioned_user_id = message_object.mentions[0]['uid']
                    user_info = client.fetchUserInfo(mentioned_user_id)
                    if user_info and 'changed_profiles' in user_info and mentioned_user_id in user_info['changed_profiles']:
                        display_name = user_info['changed_profiles'][mentioned_user_id].get('displayName', mentioned_user_id)
                    else:
                        display_name = mentioned_user_id
                    if mentioned_user_id in users:
                        balance = users[mentioned_user_id]['money']  # Lấy số dư của người chơi được mention
                        success_message = Message(text=f"Số dư của người chơi {display_name} là {balance}₫.")
                        client.sendMessage(success_message, thread_id, thread_type)
                    else:
                        error_message = Message(text="Người chơi không tồn tại.")
                        client.sendMessage(error_message, thread_id, thread_type)
                    return
                else:
                    balance = users[user_id]['money']  # Lấy số dư của người chơi
                    success_message = Message(text=f"Số dư của bạn là {balance}₫.")
                    client.sendMessage(success_message, thread_id, thread_type)
                    return
                
            else:
                url_dhbc = 'https://i.imgur.com/WxpP7YF.jpeg'
                image_path = 'modules/dhbc/cache/dhbc.png'
                image_response = requests.get(url_dhbc, headers=headers)
                with open(image_path, 'wb') as f:
                    f.write(image_response.content)
                # Get the image dimensions
                width, height = get_image_dimensions(url_dhbc, headers)
                client.sendLocalImage(
                    image_path,
                    message=Message(text="== [ ĐUỔI HÌNH BẮT CHỮ ] ==\n──────────────────\n>!dhbc 1: chơi dhbc 1 ảnh\n>!dhbc 2: chơi dhbc 2 ảnh\n>-dhbc sodu: Xem số dư còn lại\n>-dhbc bxh: Xem bảng xếp hạng 10 người chơi giàu nhất\n──────────────────\n>>>Chúc các ban 1 ngày vui<<<"),
                    thread_id=thread_id,
                    thread_type=thread_type,
                    width=width,
                    height=height,ttl=15000
                )
                return

        else:
            # Reply message: Check the session by the quoted message ID
            quoted_message_id = message_object.quote.globalMsgId
            if quoted_message_id not in game_sessions[thread_id]:
                client.replyMessage(
                    Message(text="@MEMBER, Không có câu hỏi nào đang được trả lời.", mention=Mention(author_id, length=len('@MEMBER'), offset=0)),
                    message_object,
                    thread_id,
                    thread_type,ttl=50000
                )
                return

            game_dhbc = game_sessions[thread_id][quoted_message_id]
            time_elapsed = time.time() - game_dhbc['timestamp']
            if time_elapsed > timeLimit:
                client.replyMessage(
                    Message(
                        text=f'@MEMBER, Đã hết thời gian trả lời!', 
                        mention=Mention(author_id, length=len("@MEMBER"), offset=0)
                    ),
                    message_object,
                    thread_id,
                    thread_type,ttl=30000
                )
                # Clear the session when time is up
                game_sessions[thread_id].pop(quoted_message_id, None)
                return

            dapan = " ".join(content[1:]).lower()

            if dapan == game_dhbc['tukhoa']:
                increase_user_money(user_id, coinsup)
                user_data = get_user_data(user_id)
                client.replyMessage(
                    Message(
                        text=f'@MEMBER, Chúc mừng bạn đã trả lời đúng! Bạn được thưởng {coinsup}₫.\nSố dư hiện tại: {user_data["money"]}₫',
                        mention=Mention(author_id, length=len("@MEMBER"), offset=0)
                    ),
                    message_object,
                    thread_id,
                    thread_type,ttl=300000
                )
                # Clear session after a correct answer
                game_sessions[thread_id].pop(quoted_message_id, None)

            elif dapan == 'gợi ý':
                if decrease_user_money(user_id, coinsdown):
                    user_data = get_user_data(user_id)
                    client.replyMessage(
                        Message(
                            text=f'@MEMBER, Gợi ý: {game_dhbc["suggestions"]}.\nĐã trừ {coinsdown}₫. Số dư hiện tại: {user_data["money"]}₫',
                            mention=Mention(author_id, length=len("@MEMBER"), offset=0)
                        ),
                        message_object,
                        thread_id,
                        thread_type,ttl=300000
                    )
                else:
                    client.replyMessage(
                        Message(
                            text=f'@MEMBER, Bạn không đủ tiền để xem gợi ý!',
                            mention=Mention(author_id, length=len("@MEMBER"), offset=0)
                        ),
                        message_object,
                        thread_id,
                        thread_type,ttl=15000
                    )
            else:
                client.replyMessage(
                    Message(
                        text='@MEMBER, Trả lời sai rồi!',
                        mention=Mention(author_id, length=len("@MEMBER"), offset=0)
                    ),
                    message_object,
                    thread_id,
                    thread_type,ttl=50000
                )
                
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)

def get_mitaizl():
    return {
        'dhbc': handle_dhbc_command
    }