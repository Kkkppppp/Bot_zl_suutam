import subprocess
import time
from zlapi.models import Message

des = {
    'version': "1.2.0",
    'credits': "Vũ Xuân Kiên",
    'description': "Thực thi lệnh Termux với tính năng bảo mật, giới hạn thời gian và quản lý lỗi tốt hơn."
}

def handle_run_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        command = message.split(" ", 1)
        if len(command) < 2:
            client.sendMessage(Message(text="Vui lòng nhập lệnh Termux cần thực thi."), thread_id, thread_type)
            return

        termux_command = command[1].strip()
        result = subprocess.run(termux_command, shell=True, capture_output=True, text=True, timeout=30)
        output = result.stdout if result.stdout else result.stderr

        if len(output) > 10000:
            output = output[:10000] + "\n... (Dữ liệu quá dài)"

        client.sendMessage(Message(text=f"Kết quả:\n{output}"), thread_id, thread_type,ttl=10000)

    except subprocess.TimeoutExpired:
        client.sendMessage(Message(text="Lệnh đã vượt quá thời gian cho phép (30 giây)."), thread_id, thread_type,ttl=10000)
    except subprocess.CalledProcessError as e:
        client.sendMessage(Message(text=f"Đã xảy ra lỗi khi thực thi lệnh: {e}"), thread_id, thread_type,ttl=10000)
    except PermissionError:
        client.sendMessage(Message(text="Không có quyền thực thi lệnh. Vui lòng kiểm tra quyền truy cập của bạn."), thread_id, thread_type,ttl=10000)
    except FileNotFoundError:
        client.sendMessage(Message(text="Không tìm thấy lệnh hoặc tệp tin yêu cầu. Hãy kiểm tra lại cú pháp lệnh."), thread_id, thread_type,ttl=10000)
    except OSError as e:
        client.sendMessage(Message(text=f"Lỗi hệ thống khi thực thi lệnh: {str(e)}"), thread_id, thread_type,ttl=10000)
    except Exception as e:
        client.sendMessage(Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}"), thread_id, thread_type,ttl=10000)

def get_mitaizl():
    return {
        'run': handle_run_command
    }