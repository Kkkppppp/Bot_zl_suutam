from zlapi.models import Message
from config import ADMIN
import time

des = {
    'version': "1.x.x",
    'credits': "Bản quyền con cặc",
    'description': "Thịnh"
}

def handle_sendstk_command(message, message_object, thread_id, thread_type, author_id, client):
    

    sticker_type = 3
    sticker_id = "23339"
    category_id = "10425"

    try:
        response = client.sendSticker(sticker_type, sticker_id, category_id, thread_id, thread_type)

        if response:
            client.sendMessage(Message(text="Đã gửi sticker thành công."), thread_id, thread_type)
        else:
            client.sendMessage(Message(text="Không thể gửi sticker."), thread_id, thread_type)

    except Exception as e:
        print(f"Error: {e}")
        client.sendMessage(Message(text="lỗi"), thread_id, thread_type)

def get_mitaizl():
    return {
        'sendstk': handle_sendstk_command
    }