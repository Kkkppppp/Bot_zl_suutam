import requests
from datetime import datetime
import pytz
import time

# Cấu hình API Key
API_KEY = "d7e795ae6a0d44aaa8abb1a0a7ac19e4"
VN_TZ = pytz.timezone('Asia/Ho_Chi_Minh')

def fetch_weather(area, retries=3):
    """
    Lấy thông tin thời tiết từ AccuWeather API dựa trên tên địa điểm.
    """
    try:
        # Tìm mã khu vực (areaKey) từ tên địa điểm
        location_url = f"https://api.accuweather.com/locations/v1/cities/search.json?q={requests.utils.quote(area)}&apikey={API_KEY}&language=vi-vn"
        response = requests.get(location_url)
        response.raise_for_status()
        data = response.json()

        if not data:
            return f"Không tìm thấy địa điểm: {area}!"

        area_key = data[0]['Key']

        # Gọi API để lấy thông tin thời tiết
        weather_url = f"http://api.accuweather.com/forecasts/v1/daily/1day/{area_key}?apikey={API_KEY}&details=true&language=vi"
        weather_response = requests.get(weather_url)
        weather_response.raise_for_status()
        weather_data = weather_response.json()

        return parse_weather_data(weather_data)

    except requests.exceptions.RequestException as err:
        if retries > 0:
            time.sleep(1)
            return fetch_weather(area, retries - 1)
        return f"Đã có lỗi xảy ra khi gọi API thời tiết: {err}"

def parse_weather_data(data):
    """
    Phân tích dữ liệu thời tiết và tạo thông báo.
    """
    def convert_F_to_C(fahrenheit):
        return round((fahrenheit - 32) / 1.8)

    # Lấy dữ liệu cần thiết
    daily_forecast = data.get('DailyForecasts', [{}])[0]
    headline = data.get('Headline', {}).get('Text', "Không có thông tin tiêu đề")
    min_temp = convert_F_to_C(daily_forecast.get('Temperature', {}).get('Minimum', {}).get('Value', 0))
    max_temp = convert_F_to_C(daily_forecast.get('Temperature', {}).get('Maximum', {}).get('Value', 0))
    realfeel_min = convert_F_to_C(daily_forecast.get('RealFeelTemperature', {}).get('Minimum', {}).get('Value', 0))
    realfeel_max = convert_F_to_C(daily_forecast.get('RealFeelTemperature', {}).get('Maximum', {}).get('Value', 0))
    rain_chance = daily_forecast.get('Day', {}).get('PrecipitationProbability', "Không có thông tin")
    rain_amount = daily_forecast.get('Day', {}).get('Rain', {}).get('Value', "Không có thông tin")
    day_phrase = daily_forecast.get('Day', {}).get('LongPhrase', "Không có thông tin")
    night_phrase = daily_forecast.get('Night', {}).get('LongPhrase', "Không có thông tin")

    # Tạo thông báo
    message = (
        f"📢 [THỜI TIẾT HÔM NAY]\n"
        f"🔸 {headline}\n"
        f"🌡️ Nhiệt độ: {min_temp}°C - {max_temp}°C\n"
        f"🌡️ Nhiệt độ cảm nhận: {realfeel_min}°C - {realfeel_max}°C\n"
        f"🌧️ Lượng mưa: {rain_amount} mm\n"
        f"☔ Xác suất mưa: {rain_chance}%\n"
        f"🌞 Ban ngày: {day_phrase}\n"
        f"🌙 Ban đêm: {night_phrase}\n"
    )
    return message

# Hàm xử lý lệnh thời tiết
def handle_weather_command(message, message_object, thread_id, thread_type, author_id, client):
    """
    Nhận lệnh từ người dùng và trả về thông tin thời tiết.
    """
    try:
        content = message.strip().split()
        if len(content) < 2:
            client.sendMessage(
                Message(text="⚠️ Vui lòng nhập tên địa điểm để tra cứu thời tiết! Ví dụ: `!thoitiet Hà Nội`"),
                thread_id=thread_id,
                thread_type=thread_type
            )
            return

        # Ghép tên địa điểm từ các từ sau lệnh
        area = " ".join(content[1:])
        weather_info = fetch_weather(area)
        client.sendMessage(Message(text=weather_info), thread_id, thread_type)

    except Exception as e:
        client.sendMessage(
            Message(text=f"⚠️ Đã xảy ra lỗi: {e}"),
            thread_id=thread_id,
            thread_type=thread_type
        )

# Hàm trả về các lệnh
def get_mitaizl():
    return {
        'thoitiet': handle_weather_command
    }