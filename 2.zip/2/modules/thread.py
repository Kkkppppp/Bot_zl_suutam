import json
from zlapi.models import *
from config import ADMIN
import os
import time

des = {
    'version': "1.0.2",
    'credits': "Nguyễn Quang Vũ",
    'description': "thread"
}

def is_admin(author_id):
    return author_id == ADMIN

def load_duyetbox_data():
    file_path = 'modules/cache/duyetboxdata.json'
    if not os.path.exists(file_path):
        return []
    with open(file_path, 'r') as f:
        try:
            data = json.load(f)
            return data if isinstance(data, list) else []
        except json.JSONDecodeError:
            return []

def save_duyetbox_data(data):
    with open('modules/cache/duyetboxdata.json', 'w') as f:
        json.dump(data, f, indent=4)

def handle_duyetbox_command(message, message_object, thread_id, thread_type, author_id, client):
    group_info = client.fetchGroupInfo(thread_id)
    group_name = group_info.gridInfoMap.get(thread_id, {}).get('name', 'None')
    current_time = time.strftime("%H:%M:%S - %d/%m/%Y", time.localtime())


    text = message.split()
    if len(text) < 2:
        error_message = "Vui lòng nhập lệnh đầy đỄ1�7: `thread duyet`,\n `thread ban`,\n `thread duyetall`,\n `thread banall`,\n `thread listduyet`,\n `thread list-approved`,\n `thread banid`,\n `thread duyetid`"
        client.sendMessage(Message(text=error_message), thread_id, thread_type)
        return

    action = text[1].lower()
    data = load_duyetbox_data()
    
    if action == "duyet":
        if thread_id not in data:
            data.append(thread_id)
            save_duyetbox_data(data)
            success_message = f" 1�7 Đã duyệt nhóm thành công\n 1�7 Nhóm: {group_name}\n 1�7 ID nhóm: {thread_id}\n 1�7 Vào lúc: {current_time}."
        else:
            success_message = " 1�7 Nhóm này đã được duyệt trước đó."

    elif action == "duyetid" and len(text) > 2:
        target_group_id = text[2]
        if target_group_id not in data:
            data.append(target_group_id)
            save_duyetbox_data(data)
            target_group_name = client.fetchGroupInfo(target_group_id).gridInfoMap.get(target_group_id, {}).get('name', 'None')
            success_message = f" 1�7 Đã duyệt nhóm với ID {target_group_id} thành công\n 1�7 Nhóm: {target_group_name}\n 1�7 Vào lúc: {current_time}."
            gui = Message(text="Nhóm của bạn đã được ADMIN(Nguyễn Đức Tài) duyệt tỄ1�7 xa")
            client.sendMessage(gui, thread_id=target_group_id, thread_type=ThreadType.GROUP)
        else:
            success_message = f" 1�7 Nhóm với ID {target_group_id} đã được duyệt trước đó."
    
    elif action == "ban":
        if thread_id in data:
            data.remove(thread_id)
            save_duyetbox_data(data)
            success_message = f" 1�7 Ban nhóm thành công khỏi danh sách duyệt\n 1�7 Nhóm: {group_name}\n 1�7 ID nhóm: {thread_id}\n 1�7 Vào lúc: {current_time}."
        else:
            success_message = " 1�7 Nhóm này chưa được duyệt, không thỄ1�7 ban."

    elif action == "banid" and len(text) > 2:
        target_group_id = text[2]
        if target_group_id in data:
            data.remove(target_group_id)
            save_duyetbox_data(data)
            target_group_name = client.fetchGroupInfo(target_group_id).gridInfoMap.get(target_group_id, {}).get('name', 'None')
            success_message = f" 1�7 Đã ban nhóm với ID {target_group_id} thành công\n 1�7 Nhóm: {target_group_name}\n 1�7 Vào lúc: {current_time}."
            gui = Message(text="Nhóm của bạn đã được ADMIN(Nguyễn Đức Tài) ban tỄ1�7 xa")
            client.sendMessage(gui, thread_id=target_group_id, thread_type=ThreadType.GROUP)
        else:
            success_message = f" 1�7 Nhóm với ID {target_group_id} chưa được duyệt, không thỄ1�7 ban."

    elif action == "duyetall":
        all_group_ids = list(client.fetchAllGroups().gridVerMap.keys())
        newly_approved_groups = [group_id for group_id in all_group_ids if group_id not in data]
        data.extend(newly_approved_groups)
        save_duyetbox_data(data)
        group_list = "> Đã duyệt thành công toàn bỄ1�7 nhóm:\n" + "\n".join(
            f"{i+1}:\n 1�7 Tên nhóm: {client.fetchGroupInfo(group_id).gridInfoMap.get(group_id, {}).get('name', 'None')}\n 1�7 ID: {group_id}"
            for i, group_id in enumerate(newly_approved_groups)
        )
        success_message = group_list if newly_approved_groups else "Tất cẄ1�7 các nhóm đã được duyệt."

    elif action == "banall":
        banned_groups = [group_id for group_id in data]
        data.clear()
        save_duyetbox_data(data)
        group_list = "> Đã ban thành công toàn bỄ1�7 nhóm:\n" + "\n".join(
            f"{i+1}:\n 1�7 Tên nhóm: {client.fetchGroupInfo(group_id).gridInfoMap.get(group_id, {}).get('name', 'None')}\n 1�7 ID: {group_id}"
            for i, group_id in enumerate(banned_groups)
        )
        success_message = group_list if banned_groups else "Không có nhóm nào trong danh sách duyệt đỄ1�7 ban."

    elif action == "listduyet":
        approved_groups = [group_id for group_id in data]
        group_list = "> Danh sách nhóm đã duyệt:\n" + "\n".join(
            f"{i+1}:\n 1�7 Tên nhóm: {client.fetchGroupInfo(group_id).gridInfoMap.get(group_id, {}).get('name', 'None')}\n 1�7 ID: {group_id}"
            for i, group_id in enumerate(approved_groups)
        )
        success_message = group_list if approved_groups else "Không có nhóm nào được duyệt."

    elif action == "list-approved":
        all_group_ids = list(client.fetchAllGroups().gridVerMap.keys())
        unapproved_groups = [group_id for group_id in all_group_ids if group_id not in data]
        group_list = "> Các nhóm chưa được duyệt:\n" + "\n".join(
            f"{i+1}:\n 1�7 Tên nhóm: {client.fetchGroupInfo(group_id).gridInfoMap.get(group_id, {}).get('name', 'None')}\n 1�7 ID: {group_id}"
            for i, group_id in enumerate(unapproved_groups)
        )
        success_message = group_list if unapproved_groups else "Tất cẄ1�7 các nhóm đã được duyệt."
    
    else:
        success_message = " 1�7 Vui lòng nhập lệnh đầy đỄ1�7: `thread duyet�0�4`,\n `thread ban�0�4`,\n `thread duyetall�0�4`,\n `thread banall�0�4`,\n `thread listduyet�0�4`,\n `thread list-approved�0�4`,\n `thread banid�0�4`,\n `thread duyetid�0�4`"

    client.replyMessage(Message(text=success_message), message_object, thread_id, thread_type)

def get_mitaizl():
    return {
        'thread': handle_duyetbox_command
    }
