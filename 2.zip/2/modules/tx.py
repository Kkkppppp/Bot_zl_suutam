import os
import json
import random
import requests
from datetime import datetime, timedelta
from zlapi.models import Message, MultiMsgStyle

# Config game
config = {
    "name": "tx",
    "description": "Play tx game with bet and result"
}

# File lưu trữ dữ liệu tiền
money_file = os.path.join(os.path.dirname(__file__), "money_data.json")
cooldown_data = {}

# Tải dữ liệu tiền từ file
if os.path.exists(money_file):
    with open(money_file, "r") as file:
        money_data = json.load(file)
else:
    money_data = {}

# Lưu dữ liệu tiền vào file
def save_money_data():
    try:
        with open(money_file, "w") as file:
            json.dump(money_data, file)
    except Exception as e:
        print(f"Error saving money data: {e}")

# Quản lý tiền
def add_money(user_id, amount):
    money_data[user_id] = money_data.get(user_id, 0) + amount
    save_money_data()

def subtract_money(user_id, amount):
    money_data[user_id] = max(0, money_data.get(user_id, 0) - amount)
    save_money_data()

def get_money(user_id):
    return money_data.get(user_id, 0)

# Kiểm tra cooldown
def check_cooldown(author_id, job_id):
    return (author_id in cooldown_data and
            job_id in cooldown_data[author_id] and
            datetime.now() < cooldown_data[author_id][job_id])

def update_cooldown(author_id, job_id):
    if author_id not in cooldown_data:
        cooldown_data[author_id] = {}
    cooldown_data[author_id][job_id] = datetime.now() + timedelta(seconds=60)

# Công việc và tiền thưởng
jobs = {
    "1": {"name": "làm ngành", "reward_range": (500000, 700000)},
    "2": {"name": "làm ôsin", "reward_range": (15000, 25000)},
    "3": {"name": "làm điếm", "reward_range": (700000, 900000)},
    "4": {"name": "bán máu", "reward_range": (300000, 500000)},
    "5": {"name": "làm thợ sửa chữa", "reward_range": (100000, 200000)},
    "6": {"name": "làm phục vụ quán ăn", "reward_range": (20000, 40000)},
    "7": {"name": "dạy kèm", "reward_range": (40000, 60000)},
    "8": {"name": "làm bảo vệ", "reward_range": (50000, 90000)},
    "9": {"name": "làm tài xế", "reward_range": (100000, 150000)},
    "10": {"name": "làm nhà báo", "reward_range": (200000, 300000)},
}

def get_random_reward(job_id):
    if job_id in jobs:
        return random.randint(*jobs[job_id]['reward_range'])
    return 0

# Hàm chính xử lý lệnh tài xỉu
def handle_tx_command(message, message_object, thread_id, thread_type, author_id, client):
    args = message.strip().split()
    if not args:
        functions_list = (
            "🎉 Chức năng tài xỉu: 🎉\n"
            "1. 💰 checkmoney - Xem số tiền hiện tại.\n"
            "2. 💵 setmoney - Đặt tiền cho người khác.\n"
            "3. 📋 lamviec - Danh sách công việc.\n"
            "4. 🎲 tài/xỉu <số tiền cược> - Đặt cược tài xỉu.\n"
        )
        return client.replyMessage(Message(text=functions_list), message_object, thread_id, thread_type)

    command = args[0].lower()

    # Kiểm tra tiền
    if command == "checkmoney":
        user_money = get_money(author_id)
        reply_message = f"💳 Số tiền hiện tại: {user_money} VND."
        return client.replyMessage(Message(text=reply_message), message_object, thread_id, thread_type)

    # Công việc
    if command == "lamviec":
        if len(args) != 2 or args[1] not in jobs:
            job_list = "\n".join([f"{k}: {v['name']}" for k, v in jobs.items()])
            return client.replyMessage(Message(text=f"Danh sách công việc:\n{job_list}"), message_object, thread_id, thread_type)

        job_id = args[1]
        if check_cooldown(author_id, job_id):
            return client.replyMessage(Message(text="Bạn phải chờ 60 giây để làm việc này lại."), message_object, thread_id, thread_type)

        update_cooldown(author_id, job_id)
        reward = get_random_reward(job_id)
        add_money(author_id, reward)
        return client.replyMessage(Message(text=f"Bạn đã hoàn thành công việc và nhận {reward} VND."), message_object, thread_id, thread_type)

    # Tài xỉu
    if command in ["tài", "xỉu"]:
        if len(args) < 2:
            return client.replyMessage(Message(text="Hãy nhập số tiền cược."), message_object, thread_id, thread_type)

        try:
            bet_amount = int(args[1])
        except ValueError:
            return client.replyMessage(Message(text="Số tiền cược không hợp lệ."), message_object, thread_id, thread_type)

        if get_money(author_id) < bet_amount:
            return client.replyMessage(Message(text="Bạn không có đủ tiền để cược."), message_object, thread_id, thread_type)

        response = requests.get("https://api.sumiproject.net/game/taixiu")
        if response.status_code == 200:
            data = response.json()
            result = data.get("result", "Không rõ")
            total = data.get("total", 0)
            if command == result:
                add_money(author_id, bet_amount)
                return client.replyMessage(Message(text=f"Bạn thắng! Tổng điểm: {total}. Kết quả: {result}."), message_object, thread_id, thread_type)
            else:
                subtract_money(author_id, bet_amount)
                return client.replyMessage(Message(text=f"Bạn thua! Tổng điểm: {total}. Kết quả: {result}."), message_object, thread_id, thread_type)

        return client.replyMessage(Message(text="Không thể kết nối API tài xỉu."), message_object, thread_id, thread_type)

def get_mitaizl():
    return {'tx': handle_tx_command}