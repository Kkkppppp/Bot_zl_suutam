from zlapi.models import Message
import time
import os
import requests
des = {
    'version': "1.0.2",
    'credits': "Nguyễn Phi Hoàng",
    'description': "Xem thời gian bot Hoạt Động"
}

start_time = time.time()

def handle_uptime_command(message, message_object, thread_id, thread_type, author_id, client):
    current_time = time.time()
    upt_seconds = int(current_time - start_time)

    days = upt_seconds // (24 * 3600)
    upt_seconds %= (24 * 3600)
    hours = upt_seconds // 3600
    upt_seconds %= 3600
    minutes = upt_seconds // 60
    seconds = upt_seconds % 60

    upt_message = f"Thời gian bot Online : {days} Ngày, {hours} Giờ, {minutes}  Phút, {seconds} Giây."
    
    message_to_send = Message(text=upt_message)
    
    api_url = 'https://hoangmedia.fun/image/girl'
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
        }

        response = requests.get(api_url, headers=headers)
        response.raise_for_status()
        
        # Lấy link ảnh từ JSON
        data = response.json()
        image_url = data['url']
        
        # Tải ảnh từ link
        image_response = requests.get(image_url, headers=headers)
        image_path = 'modules/cache/temp_image5.jpeg'
        
        with open(image_path, 'wb') as f:
            f.write(image_response.content)
        
        # Gửi ảnh đã tải về
        client.sendLocalImage(
            image_path, 
            message=message_to_send,
            thread_id=thread_id,
            thread_type=thread_type,ttl=60000
        )
        
        # Xóa file ảnh sau khi gửi
        os.remove(image_path)
        
    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type,ttl=60000)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type,ttl=60000)

def get_mitaizl():
    return {
        'uptime': handle_uptime_command
    }