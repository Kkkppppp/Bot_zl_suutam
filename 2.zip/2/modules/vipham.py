from zlapi.models import Message
import requests
import urllib.parse

des = {
    'version': "1.0.0",
    'credits': "YourName & Chat GPT",
    'description': "Kiểm tra vi phạm giao thông"
}


def handle_vipham_command(message, message_object, thread_id, thread_type, author_id, client):
    text = message.split()

    if len(text) < 2:
        error_message = Message(text="Lỗi: Thiếu tham số biển số xe. Ví dụ: /vipham 98B304452")
        client.sendMessage(error_message, thread_id, thread_type, ttl=10000)
        return

    bsx = " ".join(text[1:]).strip()
    encoded_bsx = urllib.parse.quote(bsx, safe='')

    # Cấu hình API
    API_KEY = 'sfund'
    url_xemay = f"https://vietcheckcar.com/api/api.php?api_key={API_KEY}&bsx={encoded_bsx}&bypass_cache=0&loaixe=2&vip=0"
    url_oto = f"https://vietcheckcar.com/api/api.php?api_key={API_KEY}&bsx={encoded_bsx}&bypass_cache=0&loaixe=1&vip=0"

    try:
        # Gửi yêu cầu API
        response_xemay = requests.get(url_xemay)
        response_oto = requests.get(url_oto)

        # Kiểm tra lỗi API
        response_xemay.raise_for_status()
        response_oto.raise_for_status()

        data_xemay = response_xemay.json()
        data_oto = response_oto.json()

        # Xử lý dữ liệu từ API
        def extract_violation_data(data, vehicle_type):
            if data.get('code') == 1:
                biensoxe = data.get('biensoxe', 'Không có thông tin')
                total_violations = data.get('totalViolations', 0)
                violations = data.get('violations', [])

                if violations:
                    violation_details = []
                    for violation in violations:
                        violation_details.append(
                            f"-> Thời gian vi phạm: {violation.get('thoi_gian_vi_pham', 'Không có thông tin')}\n"
                            f"-> Địa điểm: {violation.get('dia_diem_vi_pham', 'Không có thông tin')}\n"
                            f"-> Hành vi: {violation.get('hanh_vi_vi_pham', 'Không có thông tin')}\n"
                            f"-> Mức phạt: {violation.get('muc_phat', 'Không có thông tin')}\n"
                            f"-> Trạng thái: {violation.get('trang_thai', 'Không có thông tin')}\n"
                        )
                    violations_text = "\n\n".join(violation_details)
                    return (
                        f"-> Loại phương tiện: {vehicle_type}\n"
                        f"-> Biển số: {biensoxe}\n"
                        f"-> Tổng số vi phạm: {total_violations}\n\n"
                        f"{violations_text}"
                    )
                return f"-> Loại phương tiện: {vehicle_type}\n-> Biển số: {biensoxe}\n-> Không có vi phạm nào được tìm thấy.\n"
            return f"-> Loại phương tiện: {vehicle_type}\n-> Không tìm thấy dữ liệu hoặc lỗi API.\n"

        # Kết quả cuối cùng
        result_xemay = extract_violation_data(data_xemay, "Xe máy")
        result_oto = extract_violation_data(data_oto, "Ô tô")

        final_result = f"**Kết quả kiểm tra vi phạm giao thông**:\n\n{result_xemay}\n{result_oto}"
        message_to_send = Message(text=final_result)
        client.replyMessage(message_to_send, message_object, thread_id, thread_type, ttl=60000)

    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type, ttl=10000)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type, ttl=10000)


def get_mitaizl():
    return {
        'vipham': handle_vipham_command
    }