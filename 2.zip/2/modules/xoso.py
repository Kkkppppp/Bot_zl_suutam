from zlapi.models import Message
import requests

des = {
    'version': "1.0.0",
    'credits': "YourName & Chat GPT",
    'description': "Kiểm tra kết quả xổ số Miền Bắc"
}

def handle_xoso_command(message, message_object, thread_id, thread_type, author_id, client):
    # URL API
    api_url = 'https://nguyenmanh.name.vn/api/xsmb?apikey=OUEaxPOl'

    try:
        # Gửi yêu cầu API
        response = requests.get(api_url)
        response.raise_for_status()  # Kiểm tra lỗi HTTP
        data = response.json()

        if data.get('status') == 200:
            result = data.get('result', 'Không có dữ liệu')
            message_to_send = Message(text=f"**Kết quả xổ số Miền Bắc:**\n\n{result}")
            client.replyMessage(message_to_send, message_object, thread_id, thread_type, ttl=60000)
        else:
            error_message = Message(text="Lỗi khi lấy kết quả xổ số. Vui lòng thử lại sau.")
            client.sendMessage(error_message, thread_id, thread_type, ttl=10000)
    
    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type, ttl=10000)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type, ttl=10000)

def get_mitaizl():
    return {
        'xoso': handle_xoso_command
    }