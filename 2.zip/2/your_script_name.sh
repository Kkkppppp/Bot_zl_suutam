#!/bin/bash
echo -e "\e[36m$(figlet -f block "$1")\e[0m"